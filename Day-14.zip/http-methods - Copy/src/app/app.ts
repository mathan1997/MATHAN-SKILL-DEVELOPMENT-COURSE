import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { student} from '../student';
import { Studentservice } from './services/studentservice';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone:true,

  imports: [CommonModule, RouterOutlet],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('http-methods');

  
  students: student[] = [];

  constructor(private studentService: Studentservice) {}

  ngOnInit() {
    this.getAllStudents();
  }

  // GET
  getAllStudents() {
    this.students = this.studentService.getStudents();
  }

  // POST
  addStudent() {
    const student: student = {
      id: 3,
      name: 'Kishore',
      course: 'React'
    };
    this.studentService.addStudent(student);
    this.getAllStudents();
  }

  // PUT
  updateStudent() {
    const student: student = {
      id: 2,
      name: 'Anita',
      course: 'Spring Boot'
    };
    this.studentService.updateStudent(2, student);
    this.getAllStudents();
  }

  // DELETE
  deleteStudent() {
    this.studentService.deleteStudent(1);
    this.getAllStudents();
  }

}