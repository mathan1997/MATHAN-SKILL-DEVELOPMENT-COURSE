import { Injectable } from '@angular/core';
import { student } from '../../student';
@Injectable({
  providedIn: 'root',
})
export class Studentservice {

    // This array acts like a DATABASE
    private students: student[] = [
    { id: 1, name: 'Balaji', course: 'Angular' },
    { id: 2, name: 'chandru', course: 'Java' }
  ];
  constructor() {}
  // 🔹 GET – Read data
  getStudents(): student[] {
    return this.students;
  }
  // 🔹 POST – Add data
  addStudent(student: student): void {
    this.students.push(student);
  }
  // 🔹 PUT – Update data
  updateStudent(id: number, updatedStudent: student): void {
    const index = this.students.findIndex(s => s.id === id);
    if (index !== -1) {
      this.students[index] = updatedStudent;
    }
  }
  // 🔹 DELETE – Remove data
  deleteStudent(id: number): void {
    this.students = this.students.filter(s => s.id !== id);
  }
}
