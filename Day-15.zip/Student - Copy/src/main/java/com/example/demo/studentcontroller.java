
	package com.example.demo;


	import java.util.ArrayList;
	import java.util.List;

	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.*;

	@RestController
	@RequestMapping("/students")
	public class studentcontroller {

	    private List<student> students = new ArrayList<>();

	    // ✅ POST – Add student
	    @PostMapping
	    public ResponseEntity<String> addStudent(@RequestBody student student) {
	        students.add(student);
	        return new ResponseEntity<>("Student added successfully", HttpStatus.CREATED);
	    }

	    // ✅ GET – Get all students
	    @GetMapping
	    public ResponseEntity<List<student>> getAllStudents() {
	        return new ResponseEntity<>(students, HttpStatus.OK);
	    }

	   

	    // ✅ DELETE – Delete student
	    @DeleteMapping("/{id}")
	    public ResponseEntity<String> deleteStudent(@PathVariable int id) {

	        for (int i = 0; i < students.size(); i++) {
	            if (students.get(i).getId() == id) {
	                students.remove(i);
	                return new ResponseEntity<>("Student deleted successfully", HttpStatus.OK);
	            }
	        }

	        return new ResponseEntity<>("Student not found", HttpStatus.NOT_FOUND);
	    }
	}

