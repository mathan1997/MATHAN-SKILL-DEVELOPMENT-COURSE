import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-data-binding',
  imports: [FormsModule],
  templateUrl: './data-binding.html',
  styleUrl: './data-binding.css',
})
export class DataBinding {
  //sting interpolation
  name:"mathanmani"
//property binding
isdisabled=false;
// event binding
enablebutton(){
  this.isdisabled=true;

}
// two way binding
username='';
showalert(){
  alert('hello'+this.username)
}
}