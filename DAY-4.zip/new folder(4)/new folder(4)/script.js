<!DOCTYPE html>
<html>
<head>
    <title>My First JavaScript Page</title>
</head>
<body>

    <h1>Welcome!</h1>
    <p id="demo"></p>

    <!-- JavaScript code is inserted here -->
    <script>
        // Get the element with the id 'demo' and change its content
        document.getElementById("demo").innerHTML = "Hello, JavaScript!";
    </script>

</body>
</html>